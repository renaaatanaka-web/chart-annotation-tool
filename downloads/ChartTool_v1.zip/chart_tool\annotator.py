from PIL import Image, ImageDraw, ImageFont
import numpy as np

class ChartAnnotator:
    def __init__(self, image_path):
        self.image = Image.open(image_path).convert("RGBA")
        self.width, self.height = self.image.size
        self.draw = ImageDraw.Draw(self.image)
        # Calibration placeholders
        self.top_price = None
        self.bottom_price = None
        self.top_y = None
        self.bottom_y = None
        
        # Style presets (Approximating the vivid Pop Art style)
        self.styles = {
            "Intro": {
                "bg": "#FFFFFF", "border": "#000000", "text": "#000000", "shadow": "#444444"
            }, # Stark White
            "Scenario A": {
                "bg": "#A5D6A7", "border": "#1B5E20", "text": "#000000", "shadow": "#33691E"
            }, # Vivid Green
            "Scenario B": {
                "bg": "#FFF176", "border": "#F57F17", "text": "#000000", "shadow": "#F9A825"
            }, # Vivid Yellow (Pop)
            "Conclusion": {
                "bg": "#FFCDD2", "border": "#B71C1C", "text": "#000000", "shadow": "#C62828"
            }, # Vivid Red
            "Blue Alert": {
                "bg": "#BBDEFB", "border": "#0D47A1", "text": "#000000", "shadow": "#1565C0"
            } # Vivid Blue
        }
        
        # Try to load a font (Windows default or fallback)
        try:
            self.font_path = "C:/Windows/Fonts/meiryo.ttc" # Common Japanese font
            self.font_bold_path = "C:/Windows/Fonts/meiryob.ttc"
            self.font = ImageFont.truetype(self.font_path, 20)
            self.font_bold = ImageFont.truetype(self.font_bold_path, 22)
        except:
             try:
                self.font_path = "C:/Windows/Fonts/msgothic.ttc"
                self.font = ImageFont.truetype(self.font_path, 20)
                self.font_bold = self.font
             except:
                self.font = ImageFont.load_default()
                self.font_bold = self.font

    def calibrate(self, top_price, bottom_price, top_y=None, bottom_y=None):
        """
        Calibrates the Y-axis to map pixels to price.
        If top_y/bottom_y are not provided, assumes user set the crop to known pixel locations 
        or we default to 10% and 90% of height (simple mode).
        """
        self.top_price = float(top_price)
        self.bottom_price = float(bottom_price)
        
        # Default calibration points (can be improved with manual clicking later)
        if top_y is None:
            self.top_y = 0  # Assume top price is at the very top pixel
        else:
            self.top_y = top_y
            
        if bottom_y is None:
            self.bottom_y = self.height # Assume bottom price is at the very bottom pixel
        else:
            self.bottom_y = bottom_y

    def price_to_y(self, price):
        """Converts a price value to Y pixel coordinate."""
        if self.top_price is None:
            raise ValueError("Calibration needed.")
        
        # Linear interpolation
        # price_range = self.top_price - self.bottom_price
        # pixel_range = self.bottom_y - self.top_y
        
        # (price - bottom) / (top - bottom) = (y - bottom_y) / (top_y - bottom_y)
        # Wait, Y is inverted (0 at top).
        # Higher price = Lower Y value.
        
        ratio = (price - self.bottom_price) / (self.top_price - self.bottom_price)
        # If ratio is 1 (price = top), y should be top_y
        # If ratio is 0 (price = bottom), y should be bottom_y
        
        y = self.bottom_y - (ratio * (self.bottom_y - self.top_y))
        return int(y)

    def draw_annotation(self, price, text, style_key="Intro", x_pos=None):
        """
        Draws a bubble with text pointing to a specific price level.
        price: float target price
        text: string content
        style_key: style preset name
        x_pos: optional fixed X position (otherwise heuristic)
        """
        target_y = self.price_to_y(price)
        style = self.styles.get(style_key, self.styles["Intro"])
        
        # Text formatting (wrapping)
        lines = text.split('\n')
        
        # Measure text size
        max_w = 0
        total_h = 0
        line_heights = []
        for line in lines:
            bbox = self.draw.textbbox((0,0), line, font=self.font_bold)
            w = bbox[2] - bbox[0]
            h = bbox[3] - bbox[1]
            max_w = max(max_w, w)
            total_h += h + 5 # Line spacing
            line_heights.append(h)
            
        padding = 15
        box_w = max_w + (padding * 2)
        box_h = total_h + (padding * 2)
        
        # Determine position
        # If x_pos is None, decide based on chart side (usually text is on left or right)
        # For now, let's default to a bit left of center if not specified, 
        # or we might need a better heuristic. 
        if x_pos is None:
            x_pos = self.width // 2 # Center it for now
            
        box_x = x_pos - (box_w // 2)
        # Position box slightly *above* or *below* grid line depending on context?
        # Usually annotations are "floating" with an arrow pointing to the price line.
        
        # Let's say box is placed at a User defined X, and Y is auto-calculated 
        # to clear the arrows, but simpler: Provide (x,y) for box relative to target.
        # Actually, let's just offset Y by -100 pixels so it floats above/below.
        
        box_y = target_y - box_h - 50 # Default float above
        if box_y < 0:
            box_y = target_y + 50 # Float below if too high
            
        # Draw Shadow (Offset)
        shadow_offset = 6
        if "shadow" in style:
             self.draw.rounded_rectangle(
                [box_x + shadow_offset, box_y + shadow_offset, box_x + box_w + shadow_offset, box_y + box_h + shadow_offset], 
                radius=10, 
                fill=style["shadow"], 
                width=0
            )

        # Draw Box (Rounded rect)
        self.draw.rounded_rectangle(
            [box_x, box_y, box_x + box_w, box_y + box_h], 
            radius=10, 
            fill=style["bg"], 
            outline=style["border"], 
            width=3
        )
        
        # Draw Text
        curr_y = box_y + padding
        for line in lines:
            self.draw.text((box_x + padding, curr_y), line, fill=style["text"], font=self.font_bold)
            curr_y += line_heights.pop(0) + 5
            
        # Draw Arrow
        # From center of box bottom/top to target_y
        if box_y < target_y: # Box is above
            start_point = (box_x + box_w // 2, box_y + box_h)
        else: # Box is below
            start_point = (box_x + box_w // 2, box_y)
            
        end_point = (box_x + box_w // 2 - 20, target_y) # Mild angle
        
        self.draw.line([start_point, end_point], fill="black", width=3)
        
        # Arrowhead
        # Simple triangle
        arrow_size = 10
        # For now simple circle at target for precision
        self.draw.ellipse([end_point[0]-5, end_point[1]-5, end_point[0]+5, end_point[1]+5], fill="red")

    def get_image(self):
        return self.image
