import streamlit as st
import numpy as np
from PIL import Image
from annotator import ChartAnnotator
import io

st.set_page_config(layout="wide", page_title="チャート注釈ツール")

st.title("📈 チャート注釈作成ツール (Nanobanana Style)")
st.markdown("""
チャート画像に**正確な価格位置**で、**分かりやすい注釈**を入れるツールです。
画像生成AIの代わりに、プログラムで美麗なNanobanana風デザインを再現しています。
""")

# 1. Image Upload
uploaded_file = st.file_uploader("1. チャート画像をアップロードしてください", type=["png", "jpg", "jpeg"])

if uploaded_file is not None:
    # Save/Load logic
    image = Image.open(uploaded_file)
    st.image(image, caption="アップロードされた画像", use_container_width=True)
    
    with open("temp_chart.png", "wb") as f:
        f.write(uploaded_file.getbuffer())
    
    annotator = ChartAnnotator("temp_chart.png")
    
    # 2. Calibration
    st.sidebar.header("🛠️ 1. 初期設定 (価格合わせ)")
    with st.sidebar.expander("詳細設定を開く", expanded=True):
        st.info("チャート画像の**一番上**と**一番下**の価格を入力してください。これで矢印の位置が正確になります。")
        col1, col2 = st.columns(2)
        top_price = col1.number_input("画像の最上部の価格", value=4750.0, step=1.0)
        bottom_price = col2.number_input("画像の最下部の価格", value=4570.0, step=1.0)
        
        advanced_calib = st.checkbox("高度な設定: ピクセル位置の手動指定 (通常は不要)", value=False)
        top_y = None
        bottom_y = None
        
        if advanced_calib:
            st.write(f"画像の高さ: {annotator.height}px")
            top_y = st.number_input("最上部のY座標 (px)", value=0, min_value=0, max_value=annotator.height)
            bottom_y = st.number_input("最下部のY座標 (px)", value=annotator.height, min_value=0, max_value=annotator.height)
            
    # 3. Annotations
    st.sidebar.header("📝 2. 注釈の追加")
    
    if "annotations" not in st.session_state:
        st.session_state.annotations = []
        
    with st.sidebar.form("add_annotation"):
        st.subheader("新しい注釈を作成")
        text_input = st.text_area("表示するテキスト", "ここにテキストを入力\n改行もできます")
        price_input = st.number_input("矢印が指す価格 (Target Price)", value=4700.0)
        
        # Style mapping for display
        style_display = {
            "Intro": "白 (基本情報)",
            "Scenario A": "緑 (上昇・買いシナリオ)",
            "Scenario B": "黄色 (警戒・調整シナリオ)",
            "Conclusion": "赤 (結論・重要)",
            "Blue Alert": "青 (情報・通知)"
        }
        # Reverse mapping for logic
        style_key_map = {v: k for k, v in style_display.items()}
        
        style_selection = st.selectbox("吹き出しのデザイン", list(style_display.values()))
        style_input = style_key_map[style_selection]
        
        x_pos_input = st.slider("左右の位置調整 (%)", 0, 100, 50, help="0が左端、100が右端です")
        
        submitted = st.form_submit_button("リストに追加")
        if submitted:
            st.session_state.annotations.append({
                "text": text_input,
                "price": price_input,
                "style": style_input,
                "x_pos_pct": x_pos_input
            })
            
    # Manage existing annotations
    if st.session_state.annotations:
        st.sidebar.subheader("追加済みの注釈リスト")
        for i, note in enumerate(st.session_state.annotations):
            col_a, col_b = st.sidebar.columns([3, 1])
            col_a.text(f"価格: {note['price']}\n{note['text'][:10]}...")
            if col_b.button("削除", key=f"del_{i}"):
                st.session_state.annotations.pop(i)
                st.rerun()

    # 4. Generate
    if st.button("✨ 画像を生成する (ここをクリック)", type="primary"):
        # Apply Calibration
        annotator.calibrate(top_price, bottom_price, top_y, bottom_y)
        
        # Apply Annotations
        for note in st.session_state.annotations:
            # Convert percentage X to pixel X
            pixel_x = int(annotator.width * (note["x_pos_pct"] / 100))
            annotator.draw_annotation(note["price"], note["text"], note["style"], pixel_x)
            
        # Display Result
        result_image = annotator.get_image()
        st.success("画像が生成されました！下記ボタンからダウンロードできます。")
        st.image(result_image, caption="生成結果", use_container_width=True)
        
        # Download
        buf = io.BytesIO()
        result_image.save(buf, format="PNG")
        byte_im = buf.getvalue()
        st.download_button(
            label="💾 画像をダウンロード",
            data=byte_im,
            file_name="annotated_chart.png",
            mime="image/png"
        )

else:
    st.info("まずは上のエリアから、チャート画像をアップロードしてください。")
