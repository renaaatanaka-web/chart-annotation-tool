import streamlit as st
import numpy as np
from PIL import Image
from annotator import ChartAnnotator
import io
import google.generativeai as genai
import json
import os

st.set_page_config(layout="wide", page_title="チャート注釈ツール")

st.title("📈 チャート注釈作成ツール (Nanobanana Style)")
st.markdown("""
チャート画像に**正確な価格位置**で、**分かりやすい注釈**を入れるツールです。
「AI自動分析」機能を使えば、画像とテキストだけで全自動設定できます！
""")

def analyze_chart_with_gemini(api_key, image, analysis_text):
    """
    Simulated implementation of chart reading since real API call requires valid key.
    In a real scenario, this would send the image and text to Gemini 1.5 Flash.
    """
    genai.configure(api_key=api_key)
    
    # List of models to try in order of preference
    # Some API keys might have different access scopes or version availability
    candidate_models = [
        'gemini-1.5-flash',
        'gemini-1.5-flash-latest',
        'models/gemini-1.5-flash',
        'gemini-2.0-flash-exp', # Bleeding edge
        'gemini-pro-vision' # Legacy fallback
    ]

    last_error = None

    prompt = f"""
    You are an expert technical analyst helper. 
    Analyze the provided chart image and the user's analysis text: "{analysis_text}"
    
    1. Identify the Top Price and Bottom Price visible on the Y-axis of the chart image (OCR).
    2. Based on the user's text, extract:
       - 'sentiment': "Bullish", "Bearish", or "Neutral"
       - 'lines': Key horizontal levels (Support, Resistance, Average) mentioned.
       - 'annotations': Specific comments for specific price points.
    
    Return a JSON object ONLY:
    {{
        "top_price": <float>,
        "bottom_price": <float>,
        "sentiment": "<Bullish|Bearish|Neutral>",
        "lines": [
             {{ "price": <float>, "label": "<e.g. Resistance>", "style": "<same as annotation>" }}
        ],
        "annotations": [
            {{ "price": <float>, "text": "<short description>", "style": "<Intro|Scenario A|Scenario B|Conclusion|Blue Alert>" }}
        ]
    }}
    Style Guide:
    - Intro: General info (White)
    - Scenario A: Bullish/Buying (Green)
    - Scenario B: Bearish/Caution/Correction (Yellow)
    - Conclusion: Critical/Bottom Line (Red)
    - Blue Alert: Info (Blue)
    """
    
    for model_name in candidate_models:
        try:
            model = genai.GenerativeModel(model_name)
            response = model.generate_content([prompt, image])
            
            # Clean cleanup for JSON parsing
            text = response.text.replace("```json", "").replace("```", "").strip()
            return json.loads(text)
            
        except Exception as e:
            # If it's a "Not Found" error, try next. 
            # If it's an API key error, it will likely fail for all, but we continue anyway.
            last_error = e
            continue
    
    # If all failed
    return {"error": f"AIモデルの呼び出しに失敗しました (全モデル試行失敗)。\\n詳細: {str(last_error)}"}

# 1. Image Upload
uploaded_file = st.file_uploader("1. チャート画像をアップロードしてください", type=["png", "jpg", "jpeg"])

if uploaded_file is not None:
    # Save/Load logic
    image = Image.open(uploaded_file)
    st.image(image, caption="アップロードされた画像", use_container_width=True)
    
    with open("temp_chart.png", "wb") as f:
        f.write(uploaded_file.getbuffer())
    
    annotator = ChartAnnotator("temp_chart.png")
    
    # AI Automation Section
    st.sidebar.header("🤖 AI自動分析 (Beta)")
    
    # Validation/Persistence Logic
    KEY_FILE = "gemini_key.txt"
    
    def load_key():
        if os.path.exists(KEY_FILE):
            with open(KEY_FILE, "r") as f:
                return f.read().strip()
        return ""

    def save_key(key):
        with open(KEY_FILE, "w") as f:
            f.write(key)
            
    loaded_key = load_key()
    api_key_input = st.sidebar.text_input("Gemini API Key", value=loaded_key, type="password", help="Google AI Studioで取得した無料のキーを入力")
    analysis_text_input = st.sidebar.text_area("分析テキスト (ここに貼り付け)", height=150, placeholder="例: ビットコインは96000ドルでレジスタンス。移動平均線がサポートとして機能しており、強気相場継続です。")
    
    if st.sidebar.button("🤖 AIで全自動設定する"):
        if not api_key_input:
            st.sidebar.error("APIキーを入力してください！")
        elif not analysis_text_input:
             st.sidebar.error("分析テキストを入力してください！")
        else:
             # Save key for future use
             save_key(api_key_input)
             
             with st.spinner("AIが画像を分析中... (数秒かかります)"):
                 result = analyze_chart_with_gemini(api_key_input, image, analysis_text_input)
                 if "error" in result:
                     st.sidebar.error(f"エラーが発生しました: {result['error']}")
                 else:
                     st.session_state.ai_result = result
                     st.session_state.annotations_loaded = False # Force reload
                     st.sidebar.success("分析完了！設定を適用しました。")
                     st.rerun()

    # Apply AI Result if exists
    default_top = 4750.0
    default_bottom = 4570.0
    
    if "ai_result" in st.session_state:
        res = st.session_state.ai_result
        default_top = res.get("top_price", default_top)
        default_bottom = res.get("bottom_price", default_bottom)
        
        # Load Annotations & Lines & Sentiment (Only once per analysis)
        if "annotations_loaded" not in st.session_state or not st.session_state.annotations_loaded:
            # Load Annotations
            st.session_state.annotations = []
            for note in res.get("annotations", []):
                 st.session_state.annotations.append({
                    "text": note["text"],
                    "price": note["price"],
                    "style": note["style"],
                    "x_pos_pct": 50 
                })
            
            # Load Lines
            st.session_state.lines = []
            for line in res.get("lines", []):
                st.session_state.lines.append({
                    "price": line["price"],
                    "label": line.get("label", "Line"),
                    "style": line.get("style", "Intro")
                })
                
            # Load Sentiment
            st.session_state.sentiment = res.get("sentiment", "Neutral")
            
            st.session_state.annotations_loaded = True
            
    # Initialize session states for new features if empty
    if "lines" not in st.session_state: st.session_state.lines = []
    if "sentiment" not in st.session_state: st.session_state.sentiment = "Neutral"

    # LOWER SECTIONS (Calibration, Manual Input) omitted here but implied to follow structure 
    # (Calibration is same)
    
    # 2. Calibration
    st.sidebar.header("🛠️ 1. 初期設定 (価格合わせ)")
    with st.sidebar.expander("詳細設定を開く", expanded=True):
        st.info("チャート画像の**一番上**と**一番下**の価格を入力してください。")
        col1, col2 = st.columns(2)
        top_price = col1.number_input("画像の最上部の価格", value=float(default_top), step=1.0)
        bottom_price = col2.number_input("画像の最下部の価格", value=float(default_bottom), step=1.0)
        
        advanced_calib = st.checkbox("高度な設定", value=False)
        top_y = None
        bottom_y = None
        if advanced_calib:
            top_y = st.number_input("最上部のY座標", value=0)
            bottom_y = st.number_input("最下部のY座標", value=annotator.height)

    # 3. Annotations & Lines
    st.sidebar.header("📝 2. 注釈・分析の追加")
    
    # Sentiment Selector
    st.session_state.sentiment = st.sidebar.selectbox("相場全体の方向性 (Badge)", ["Bullish", "Bearish", "Neutral"], index=["Bullish", "Bearish", "Neutral"].index(st.session_state.sentiment))

    tab1, tab2 = st.sidebar.tabs(["吹き出し (Annotations)", "水平ライン (Lines)"])
    
    with tab1:
        # Existing Annotation Form logic...
        if "annotations" not in st.session_state: st.session_state.annotations = []
        with st.form("add_annotation"):
            st.write("注釈を追加")
            t_input = st.text_input("テキスト")
            p_input = st.number_input("価格", value=float(default_top))
            # ... simplified for replace ... 
            s_display = {"Intro": "白", "Scenario A": "緑", "Scenario B": "黄色", "Conclusion": "赤", "Blue Alert": "青"}
            s_map = {v: k for k, v in s_display.items()}
            style_sel = st.selectbox("デザイン", list(s_display.values()))
            
            if st.form_submit_button("追加"):
                st.session_state.annotations.append({"text": t_input, "price": p_input, "style": s_map[style_sel], "x_pos_pct": 50})

        # List existing annotations
        for i, note in enumerate(st.session_state.annotations):
            c1, c2 = st.columns([3, 1])
            c1.caption(f"{note['price']}: {note['text']}")
            if c2.button("×", key=f"del_note_{i}"):
                st.session_state.annotations.pop(i)
                st.rerun()

    with tab2:
        with st.form("add_line"):
            st.write("水平ラインを追加")
            l_price = st.number_input("価格 (Line Price)", value=float(default_top))
            l_label = st.text_input("ラベル (例: Resistance)")
            style_sel_l = st.selectbox("色設定", list(s_display.values()))
            
            if st.form_submit_button("ライン追加"):
                st.session_state.lines.append({"price": l_price, "label": l_label, "style": s_map[style_sel_l]})
        
        # List existing lines
        for i, line in enumerate(st.session_state.lines):
            c1, c2 = st.columns([3, 1])
            c1.caption(f"Line {line['price']}: {line['label']}")
            if c2.button("×", key=f"del_line_{i}"):
                st.session_state.lines.pop(i)
                st.rerun()

    # 4. Generate
    if st.button("✨ 画像を生成する (ここをクリック)", type="primary"):
        if top_price <= bottom_price:
            st.error("エラー: 価格設定が不正です。")
        else:
            annotator.calibrate(top_price, bottom_price, top_y, bottom_y)
            
            # Draw Sentiment Badge
            annotator.draw_sentiment_badge(st.session_state.sentiment)
            
            # Draw Horizontal Lines
            for line in st.session_state.lines:
                annotator.draw_horizontal_line(line["price"], line["label"], line["style"])

            # Draw Annotations
            for note in st.session_state.annotations:
                pixel_x = int(annotator.width * (note["x_pos_pct"] / 100))
                try:
                    annotator.draw_annotation(note["price"], note["text"], note["style"], pixel_x)
                except: pass
            
            result_image = annotator.get_image()
            st.image(result_image, caption="Generated Charts", use_container_width=True)
            
            buf = io.BytesIO()
            result_image.save(buf, format="PNG")
            st.download_button("💾 画像をダウンロード", buf.getvalue(), "chart_analysis.png", "image/png")


else:
    st.info("まずは上のエリアから、チャート画像をアップロードしてください。")
