import streamlit as st
import numpy as np
from PIL import Image
from annotator import ChartAnnotator
import io
import google.generativeai as genai
import json

st.set_page_config(layout="wide", page_title="チャート注釈ツール")

st.title("📈 チャート注釈作成ツール (Nanobanana Style)")
st.markdown("""
チャート画像に**正確な価格位置**で、**分かりやすい注釈**を入れるツールです。
「AI自動分析」機能を使えば、画像とテキストだけで全自動設定できます！
""")

def analyze_chart_with_gemini(api_key, image, analysis_text):
    """
    Simulated implementation of chart reading since real API call requires valid key.
    In a real scenario, this would send the image and text to Gemini 1.5 Flash.
    """
    genai.configure(api_key=api_key)
    
    # List of models to try in order of preference
    # Some API keys might have different access scopes or version availability
    candidate_models = [
        'gemini-1.5-flash',
        'gemini-1.5-flash-latest',
        'models/gemini-1.5-flash',
        'gemini-2.0-flash-exp', # Bleeding edge
        'gemini-pro-vision' # Legacy fallback
    ]

    last_error = None

    prompt = f"""
    You are an expert technical analyst helper. 
    Analyze the provided chart image and the user's analysis text: "{analysis_text}"
    
    1. Identify the Top Price and Bottom Price visible on the Y-axis of the chart image (OCR).
    2. Based on the user's text, extract key price levels and their sentiment/type.
    
    Return a JSON object ONLY, with this structure:
    {{
        "top_price": <float>,
        "bottom_price": <float>,
        "annotations": [
            {{ "price": <float>, "text": "<short description>", "style": "<Intro|Scenario A|Scenario B|Conclusion|Blue Alert>" }}
        ]
    }}
    Style Guide:
    - Intro: General info (White)
    - Scenario A: Bullish/Buying (Green)
    - Scenario B: Bearish/Caution/Correction (Yellow)
    - Conclusion: Critical/Bottom Line (Red)
    - Blue Alert: Info (Blue)
    """

    for model_name in candidate_models:
        try:
            model = genai.GenerativeModel(model_name)
            response = model.generate_content([prompt, image])
            
            # Clean cleanup for JSON parsing
            text = response.text.replace("```json", "").replace("```", "").strip()
            return json.loads(text)
            
        except Exception as e:
            # If it's a "Not Found" error, try next. 
            # If it's an API key error, it will likely fail for all, but we continue anyway.
            last_error = e
            continue
    
    # If all failed
    return {"error": f"AIモデルの呼び出しに失敗しました (全モデル試行失敗)。\\n詳細: {str(last_error)}"}

# 1. Image Upload
uploaded_file = st.file_uploader("1. チャート画像をアップロードしてください", type=["png", "jpg", "jpeg"])

if uploaded_file is not None:
    # Save/Load logic
    image = Image.open(uploaded_file)
    st.image(image, caption="アップロードされた画像", use_container_width=True)
    
    with open("temp_chart.png", "wb") as f:
        f.write(uploaded_file.getbuffer())
    
    annotator = ChartAnnotator("temp_chart.png")
    
    # AI Automation Section
    st.sidebar.header("🤖 AI自動分析 (Beta)")
    api_key_input = st.sidebar.text_input("Gemini API Key", type="password", help="Google AI Studioで取得した無料のキーを入力")
    analysis_text_input = st.sidebar.text_area("分析テキスト (ここに貼り付け)", height=150, placeholder="例: ビットコインは96000ドルでレジスタンス。94500ドルまで調整する可能性があります...")
    
    if st.sidebar.button("🤖 AIで全自動設定する"):
        if not api_key_input:
            st.sidebar.error("APIキーを入力してください！")
        elif not analysis_text_input:
             st.sidebar.error("分析テキストを入力してください！")
        else:
             with st.spinner("AIが画像を分析中... (数秒かかります)"):
                 result = analyze_chart_with_gemini(api_key_input, image, analysis_text_input)
                 if "error" in result:
                     st.sidebar.error(f"エラーが発生しました: {result['error']}")
                 else:
                     st.session_state.ai_result = result
                     st.sidebar.success("分析完了！設定を適用しました。")
                     st.rerun()

    # Apply AI Result if exists
    default_top = 4750.0
    default_bottom = 4570.0
    
    if "ai_result" in st.session_state:
        res = st.session_state.ai_result
        default_top = res.get("top_price", default_top)
        default_bottom = res.get("bottom_price", default_bottom)
        # Update annotations if not already manually modified (optional logic, simplifed here)
        if "annotations_loaded" not in st.session_state:
            st.session_state.annotations = []
            for note in res.get("annotations", []):
                 st.session_state.annotations.append({
                    "text": note["text"],
                    "price": note["price"],
                    "style": note["style"],
                    "x_pos_pct": 50 # Default center
                })
            st.session_state.annotations_loaded = True
    
    # 2. Calibration
    with st.sidebar.expander("詳細設定を開く", expanded=True):
        st.info("チャート画像の**一番上**と**一番下**の価格を入力してください。これで矢印の位置が正確になります。")
        col1, col2 = st.columns(2)
        top_price = col1.number_input("画像の最上部の価格", value=float(default_top), step=1.0)
        bottom_price = col2.number_input("画像の最下部の価格", value=float(default_bottom), step=1.0)
        
        advanced_calib = st.checkbox("高度な設定: ピクセル位置の手動指定 (通常は不要)", value=False)
        top_y = None
        bottom_y = None
        
        if advanced_calib:
            st.write(f"画像の高さ: {annotator.height}px")
            top_y = st.number_input("最上部のY座標 (px)", value=0, min_value=0, max_value=annotator.height)
            bottom_y = st.number_input("最下部のY座標 (px)", value=annotator.height, min_value=0, max_value=annotator.height)
            
    # 3. Annotations
    st.sidebar.header("📝 2. 注釈の追加")
    
    if "annotations" not in st.session_state:
        st.session_state.annotations = []
        
    with st.sidebar.form("add_annotation"):
        st.subheader("新しい注釈を作成")
        text_input = st.text_area("表示するテキスト", "ここにテキストを入力\n改行もできます")
        price_input = st.number_input("矢印が指す価格 (Target Price)", value=4700.0)
        
        # Style mapping for display
        style_display = {
            "Intro": "白 (基本情報)",
            "Scenario A": "緑 (上昇・買いシナリオ)",
            "Scenario B": "黄色 (警戒・調整シナリオ)",
            "Conclusion": "赤 (結論・重要)",
            "Blue Alert": "青 (情報・通知)"
        }
        # Reverse mapping for logic
        style_key_map = {v: k for k, v in style_display.items()}
        
        style_selection = st.selectbox("吹き出しのデザイン", list(style_display.values()))
        style_input = style_key_map[style_selection]
        
        x_pos_input = st.slider("左右の位置調整 (%)", 0, 100, 50, help="0が左端、100が右端です")
        
        submitted = st.form_submit_button("リストに追加")
        if submitted:
            st.session_state.annotations.append({
                "text": text_input,
                "price": price_input,
                "style": style_input,
                "x_pos_pct": x_pos_input
            })
            
    # Manage existing annotations
    if st.session_state.annotations:
        st.sidebar.subheader("追加済みの注釈リスト")
        for i, note in enumerate(st.session_state.annotations):
            col_a, col_b = st.sidebar.columns([3, 1])
            col_a.text(f"価格: {note['price']}\n{note['text'][:10]}...")
            if col_b.button("削除", key=f"del_{i}"):
                st.session_state.annotations.pop(i)
                st.rerun()

    # 4. Generate
    if st.button("✨ 画像を生成する (ここをクリック)", type="primary"):
        # Validation checks
        if top_price <= bottom_price:
            st.error("⚠️ エラー: 「一番上の価格」は「一番下の価格」より高い必要があります。")
        else:
            # Apply Calibration
            annotator.calibrate(top_price, bottom_price, top_y, bottom_y)
            
            # Apply Annotations
            for note in st.session_state.annotations:
                # Convert percentage X to pixel X
                pixel_x = int(annotator.width * (note["x_pos_pct"] / 100))
                
                # Check bounds
                try:
                    target_y = annotator.price_to_y(note["price"])
                    if target_y < 0 or target_y > annotator.height:
                        st.warning(f"⚠️ 注意: 注釈「{note['text'][:5]}...」の価格 ({note['price']}) が画面範囲外です。初期設定の価格範囲を確認してください。")
                except:
                    pass

                annotator.draw_annotation(note["price"], note["text"], note["style"], pixel_x)
                
            # Display Result
            result_image = annotator.get_image()
            st.success("画像が生成されました！下記ボタンからダウンロードできます。")
            st.image(result_image, caption="生成結果", use_container_width=True)
            
            # Download
            buf = io.BytesIO()
            result_image.save(buf, format="PNG")
            byte_im = buf.getvalue()
            st.download_button(
                label="💾 画像をダウンロード",
                data=byte_im,
                file_name="annotated_chart.png",
                mime="image/png"
            )

else:
    st.info("まずは上のエリアから、チャート画像をアップロードしてください。")
