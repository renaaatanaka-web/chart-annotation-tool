import streamlit as st
import numpy as np
from PIL import Image, ImageFont, ImageDraw
from annotator import ChartAnnotator
import io
import google.generativeai as genai
import json
import os

# -----------------------------------------------------------------------------
# Configuration & CSS
# -----------------------------------------------------------------------------
# -----------------------------------------------------------------------------
# Configuration & CSS
# -----------------------------------------------------------------------------
st.set_page_config(layout="wide", page_title="チャート注釈ツール Pro", page_icon="📈")

# Custom CSS for "Nanobanana Pro" Look (High Contrast JP)
st.markdown("""
<style>
    /* Global Dark Theme Overrides */
    .stApp {
        background-color: #0E1117;
        color: #FFFFFF;
    }
    
    /* Headers */
    h1, h2, h3 {
        font-family: "Noto Sans JP", sans-serif;
        font-weight: 700;
        color: #FFFFFF !important; /* Solid White for readability */
        text-shadow: 0px 0px 10px rgba(255, 255, 255, 0.2);
    }
    
    /* Buttons */
    .stButton>button {
        border-radius: 20px;
        background: linear-gradient(90deg, #FF8C00 0%, #FF0080 100%); /* Warm high-vis gradient */
        color: white;
        font-weight: bold;
        border: none;
        padding: 0.5rem 2rem;
        transition: transform 0.2s;
    }
    .stButton>button:hover {
        transform: scale(1.05);
        color: white;
    }
    div[data-testid="stForm"] .stButton>button {
         background: #333;
    }

    /* Tabs */
    .stTabs [data-baseweb="tab-list"] {
        gap: 20px;
    }
    .stTabs [data-baseweb="tab"] {
        height: 50px;
        white-space: pre-wrap;
        background-color: #1a1c24;
        border-radius: 10px 10px 0 0;
        gap: 1px;
        padding-top: 10px;
        padding-bottom: 10px;
        color: #ddd;
    }
    .stTabs [aria-selected="true"] {
        background-color: #333;
        color: #FF8C00;
        border-top: 2px solid #FF8C00;
    }

    /* Input Fields */
    .stTextInput>div>div>input, .stTextArea>div>div>textarea {
        background-color: #262730;
        color: #FAFAFA;
        border-radius: 10px;
    }
    
    /* Metric Cards */
    div[data-testid="stMetricValue"] {
        font-size: 1.2rem;
    }
    
    /* Label Colors */
    label {
        color: #E0E0E0 !important;
    }
</style>
""", unsafe_allow_html=True)

# -----------------------------------------------------------------------------
# Helper Functions
# -----------------------------------------------------------------------------
KEY_FILE = "gemini_key.txt"

def load_key():
    if os.path.exists(KEY_FILE):
        with open(KEY_FILE, "r") as f:
            return f.read().strip()
    return ""

def save_key(key):
    with open(KEY_FILE, "w") as f:
        f.write(key)

def analyze_chart_with_gemini(api_key, image, analysis_text):
    genai.configure(api_key=api_key)
    
    candidate_models = [
        'gemini-1.5-flash',
        'gemini-1.5-flash-latest',
        'models/gemini-1.5-flash',
        'gemini-2.0-flash-exp',
        'gemini-pro-vision'
    ]

    last_error = None

    prompt = f"""
    You are an expert technical analyst helper. 
    Analyze the provided chart image and the user's analysis text: "{analysis_text}"
    
    1. Identify the Top Price and Bottom Price visible on the Y-axis of the chart image (OCR).
    2. Based on the user's text, extract:
       - 'sentiment': "Bullish", "Bearish", or "Neutral"
       - 'lines': Key horizontal levels (Support, Resistance, Average) mentioned.
       - 'annotations': Specific comments for specific price points.
    
    Return a JSON object ONLY:
    {{
        "top_price": <float>,
        "bottom_price": <float>,
        "sentiment": "<Bullish|Bearish|Neutral>",
        "lines": [
             {{ "price": <float>, "label": "<e.g. Resistance>", "style": "<Intro|Scenario A|Scenario B|Conclusion|Blue Alert>" }}
        ],
        "annotations": [
            {{ "price": <float>, "text": "<short description>", "style": "<Intro|Scenario A|Scenario B|Conclusion|Blue Alert>" }}
        ]
    }}
    """
    
    for model_name in candidate_models:
        try:
            model = genai.GenerativeModel(model_name)
            response = model.generate_content([prompt, image])
            text = response.text.replace("```json", "").replace("```", "").strip()
            return json.loads(text)
        except Exception as e:
            last_error = e
            continue
    
    return {"error": f"AIエラー: {str(last_error)}"}

# -----------------------------------------------------------------------------
# Main Application Flow
# -----------------------------------------------------------------------------

st.title("📈 チャート注釈作成ツール Pro")
st.markdown("##### AIの力で、プロ級の分析画像を数秒で作成。")

# --- Session State Initialization ---
if "lines" not in st.session_state: st.session_state.lines = []
if "annotations" not in st.session_state: st.session_state.annotations = []
if "sentiment" not in st.session_state: st.session_state.sentiment = "Neutral"

# 1. UPLOAD IMAGE
with st.container():
    st.markdown("### 1. チャート画像のアップロード")
    uploaded_file = st.file_uploader("", type=["png", "jpg", "jpeg"], label_visibility="collapsed")

if uploaded_file is not None:
    # Load Image
    image = Image.open(uploaded_file)
    with open("temp_chart.png", "wb") as f:
        f.write(uploaded_file.getbuffer())
    annotator = ChartAnnotator("temp_chart.png")
    
    # Layout: Left Control Panel (Tabs), Right Preview
    col_control, col_preview = st.columns([1, 1.5])

    with col_control:
        st.markdown("### 2. 設定・分析")
        tab_ai, tab_manual = st.tabs(["🤖 AIアシスタント", "🛠️ 手動ツール"])

        # --- TAB A: AI ASSISTANT ---
        with tab_ai:
            st.info("分析テキストを貼り付けてください。あとはAIにお任せ。")
            
            loaded_key = load_key()
            api_key_input = st.text_input("Gemini API キー", value=loaded_key, type="password", placeholder="Google AI Studioのキーを入力")
            if api_key_input: save_key(api_key_input)
            
            analysis_text = st.text_area("分析コメント / 相場観", height=150, placeholder="例: ビットコインは96000ドルのサポートを守っています...")
            
            if st.button("✨ AIで自動分析する", type="primary"):
                if not api_key_input or not analysis_text:
                    st.error("APIキーとテキストを入力してください。")
                else:
                    with st.spinner("AIがチャートとセンチメントを分析中..."):
                        res = analyze_chart_with_gemini(api_key_input, image, analysis_text)
                        if "error" in res:
                            st.error(res["error"])
                        else:
                            # Update Session State
                            st.session_state.ai_result = res
                            # Load extracted values
                            st.session_state.lines = res.get("lines", [])
                            st.session_state.annotations = res.get("annotations", [])
                            st.session_state.sentiment = res.get("sentiment", "Neutral")
                            # Trigger re-run to update preview
                            st.session_state.calib_top = res.get("top_price", 4750.0)
                            st.session_state.calib_bottom = res.get("bottom_price", 4570.0)
                            st.success("分析完了！")
                            st.rerun()

        # --- TAB B: MANUAL TOOLS ---
        with tab_manual:
            st.markdown("#### 価格設定 (Calibration)")
            c1, c2 = st.columns(2)
            # Use session state for default values if AI determined them
            def_top = st.session_state.get("calib_top", 4750.0)
            def_bottom = st.session_state.get("calib_bottom", 4570.0)
            
            calib_top = c1.number_input("最上部の価格", value=float(def_top))
            calib_bottom = c2.number_input("最下部の価格", value=float(def_bottom))
            
            st.markdown("#### 相場観 (Sentiment)")
            st.session_state.sentiment = st.selectbox("相場全体の方向性", ["Bullish", "Bearish", "Neutral"], index=["Bullish", "Bearish", "Neutral"].index(st.session_state.sentiment))
            
            st.markdown("#### ラインと注釈の編集")
            with st.expander("水平ラインの管理"):
                 for i, line in enumerate(st.session_state.lines):
                    cc1, cc2 = st.columns([4,1])
                    cc1.text(f"Line @ {line['price']} ({line.get('label','')})")
                    if cc2.button("削除", key=f"dl_{i}"):
                        st.session_state.lines.pop(i)
                        st.rerun()
                 
                 with st.form("new_line"):
                     nl_price = st.number_input("価格")
                     nl_label = st.text_input("ラベル")
                     if st.form_submit_button("ライン追加"):
                         st.session_state.lines.append({"price": nl_price, "label": nl_label, "style": "Intro"})
                         st.rerun()

            with st.expander("テキスト注釈の管理"):
                 for i, note in enumerate(st.session_state.annotations):
                    cc1, cc2 = st.columns([4,1])
                    cc1.text(f"@{note['price']}: {note['text'][:15]}...")
                    if cc2.button("削除", key=f"dn_{i}"):
                        st.session_state.annotations.pop(i)
                        st.rerun()
    
    # --- PREVIEW SECTION ---
    with col_preview:
        st.markdown("### 3. プレビュー & ダウンロード")
        
        # Get calibration values from the manual tab inputs (which default to AI values)
        # Note: In Streamlit, getting values from other columns is tricky if not in session state or same form.
        # Simplification: We rely on the variables `calib_top`, `calib_bottom` defined above.
        
        if calib_top <= calib_bottom:
             st.warning("設定エラー: 最上部の価格は最下部より高く設定してください。")
        else:
            annotator.calibrate(calib_top, calib_bottom)
            
            # Draw Process
            annotator.draw_sentiment_badge(st.session_state.sentiment)
            
            for line in st.session_state.lines:
                annotator.draw_horizontal_line(line["price"], line.get("label",""), line.get("style","Intro"))
            
            for note in st.session_state.annotations:
                # Default X if missing (AI might not provide it, or manual add might miss it)
                x_pct = note.get("x_pos_pct", 50)
                px_x = int(annotator.width * (x_pct / 100))
                try:
                    annotator.draw_annotation(note["price"], note["text"], note.get("style","Intro"), px_x)
                except: pass
            
            final_img = annotator.get_image()
            st.image(final_img, use_container_width=True, caption="生成結果 - プレビュー")
            
            buf = io.BytesIO()
            final_img.save(buf, format="PNG")
            st.download_button("💾 高解像度画像をダウンロード", buf.getvalue(), "chart_pro.png", "image/png", type="primary", use_container_width=True)

    # --- SIDEBAR FOOTER (EXIT BUTTON) ---
    with st.sidebar:
        st.markdown("---")
        if st.button("🚫 アプリを完全に終了する", help="バックグラウンドのプロセスも停止して終了します"):
            st.warning("アプリを終了しています... ウィンドウを閉じてください。")
            import time
            time.sleep(1)
            os._exit(0)

else:
    # Placeholder when no image is uploaded
    st.info("👆 まずはチャート画像をアップロードしてください。")
